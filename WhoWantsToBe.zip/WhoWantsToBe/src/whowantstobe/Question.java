/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package whowantstobe;

/**
 *
 * @author Mariia
 */

public class Question {
    String text;
    String[] answers=new String[4];
    byte answer;
    byte power;
    boolean was;

    Question(String[] s){
        this.text=s[0];
        this.answers[0]=s[1];
        this.answers[1]=s[2];
        this.answers[2]=s[3];
        this.answers[3]=s[4];
        this.answer=Byte.parseByte(s[5]);
        this.power=Byte.parseByte(s[6]);
        was=false;
    }
     public String[] AskQuestion(){
        was=true;
        String[] x=new String[5];
        x[0]=text;
        x[1]=answers[0];
        x[2]=answers[1];
        x[3]=answers[2];
        x[4]=answers[3];
        return x;
     }
     public boolean CheckAnswer(byte x){
        if (answer==x) return true;
        else return false;
     }
}
