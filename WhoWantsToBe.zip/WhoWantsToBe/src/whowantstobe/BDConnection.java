/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package whowantstobe;
import java.sql.*;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
/**
 *
 * @author Mariia
 */
public class BDConnection {
    Connection conn=null;
    
    public void open(){
        try 
        {
            Class.forName("org.sqlite.JDBC");
            conn=DriverManager.getConnection("jdbc:sqlite:c:\\sqlite\\users.db");
                
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage());
        }
    }
    
    public void insert(String name, int price){
        String query="Insert into users (name, price) values('"+name+"', '"+price+"')";
        try {
            Statement statement=conn.createStatement();
            statement.executeUpdate(query);
            statement.close();
    
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage());
        }
    }
    
    public ResultSet select(){
        try {
            Statement statement=conn.createStatement();
            String query ="select name, price from users order by price DESC";
            ResultSet rs=statement.executeQuery(query);
            return rs; 
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage());
            return null;
        }             
    }
    
    public void close(){
        
        try {
            conn.close();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage());
        }
    }
    
    
}
