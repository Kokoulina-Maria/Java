/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package whowantstobe;

/**
 *
 * @author Mariia
 */
import java.io.*;

import java.util.ArrayList;
import java.util.List;
import java.util.*;


import  java.util.Random;

public class AllQuestions {
    List<Question> mas=new ArrayList<>();
    List<Question> t;
    int currentQuestion;
    Random r=new Random();

    AllQuestions(String fileName){
        try {
            FileInputStream f = new FileInputStream(fileName);
            BufferedReader br=new BufferedReader(new InputStreamReader(f));
            String str;
            br.readLine();
            while ((str=br.readLine())!=null){
                String[] s=str.split("\t");
                Question x=new Question(s);
                boolean i= Collections.addAll(mas, x);
            }
            currentQuestion=-1;
        }
        catch(IOException e){
            System.out.println("Ошибка");
        }
    }

    public String[] GetQuestion(byte power){

        t=new ArrayList<>();
        boolean b;
        for (Question i:mas){
            if ((i.power==power)&&(!i.was)) b= Collections.addAll(t, i);
        }
        if (t.isEmpty()) return null;
        currentQuestion = r.nextInt(t.size());
        Question x=t.get(currentQuestion);
        String[] atr=t.get(currentQuestion).AskQuestion();
        return atr;
    }

    public boolean CheckAnswer(byte ans){
        return t.get(currentQuestion).CheckAnswer(ans);
    }

    public byte RightAnswer(){
        return t.get(currentQuestion).answer;
     }

}
